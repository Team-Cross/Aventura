#ifndef MLP_Network_H
#define MLP_Network_H
#include "MLP_Layer.h"
#include "MLP_Global.h"


class MLP_Network {
    
private:
    MLP_Layer *layer_Network;
    
    float**  input_network;
    float** output_network;
    float** desired_output;
    
    int num_training_set;
    int num_input_Node;
    int num_hidden_Node;
    int num_output_Node;
    int num_hidden_Layer;
    int num_mini_batch;
    int batch_count;

    float learning_rate;
    float sumError;
    
public:
    MLP_Network(int num_input_Node,int num_hidden_Node,int num_output_Node,
                int num_hidden_Layer,int num_training_set, int num_mini_batch,
                float learning_rate,float **trainData, float **Desired_output);
    ~MLP_Network();
    void Allocate_Network();
    void Deallocate_Network();
    
    void Train();
    void Forward_Propagate_Network(int num);
    void Backward_Propagate_Network(int num);
    void Update_Weight_Network();
    void Handle_Error();
    
    void Train_Print_Result();
    void Test_Print_Result(float** input, float** desired_output, int num_test_set);

	float get_accuarcy();
    
};

#endif
